import pickle
from community_newman import partition
import plotting
from utils import get_modularity
import community_louvain
import networkx as nx
import matplotlib.pyplot as plt
from sys import argv
import numpy as np
import pandas as pd
import os

script, infilename, outfilename = argv

def read_graph(G):
    f = open(infilename, 'r')
    lines = f.readlines()

    for line in lines:
        edgelist = list(map(str,line.strip().split(",")))
        u = edgelist[0]
        v = edgelist[1]
        #w = float(edgelist[2])
        #G.add_edge(u, v, weight=w)

        try:
            w = float(edgelist[2])
            flag = "weighted"
            G.add_edge(u, v, weight=w)
        except:
            G.add_edge(u, v)
            flag = "unweighted"

    # print u,v,w
    print(G.number_of_nodes(), "nodes")
    print(G.number_of_edges(), "edges")
    save_obj(G, 'Graph_obj_pickle')
    f.close()
    return flag


def save_obj(obj, filename):
    f = open(filename, 'wb')
    pickle.dump(obj, f)
    f.close()

def csv_graph(fname):
    G=nx.Graph()
    f = open(fname, 'r')
    lines = f.readlines()

    for line in lines:
        edgelist = list(map(str,line.strip().split(",")))
        u = edgelist[0]
        v = edgelist[1]
        #w = float(edgelist[2])
        #G.add_edge(u, v, weight=w)

        try:
            w = float(edgelist[2])
            flag = "weighted"
            G.add_edge(u, v, weight=w)
        except:
            G.add_edge(u, v)
            flag = "unweighted"
    f.close()       
    return G

def main():
    """partitions the graph G into communities"""
    G = nx.Graph()
    flag = read_graph(G)
    pos = nx.spring_layout(G)
    nx.draw_networkx(G, pos, node_size=75, alpha=0.8, node_color="skyblue")
    if flag=="weighted":
        labels = nx.get_edge_attributes(G, 'weight')
        nx.draw_networkx_edge_labels(G, pos, edge_labels=labels)
    plt.show()
    node_cmap = "blue"
    plotting.plotin3d(G,node_cmap)



    print('Computing clusters ...')
    if flag=="weighted":
        part = community_louvain.best_partition(G)
    else:
        part = partition(G)
    print(part)
    unique_coms = np.unique(list(part.values()))
    cmap = {
        0: 'maroon',
        1: 'teal',
        2: 'skyblue',
        3: 'orange',
        4: 'green',
        5: 'yellow',
        6: 'red',
        7: 'hotpink',
        8: 'azure',
        9: 'darkolivegreen',
        10: 'turquoise'
    }
    node_cmap = [cmap[v] for _, v in part.items()]
    for comm in set(part.values()):
        print("Community %d" % comm)
        print(', '.join([str(node) for node in part if part[node] == comm]))
    print("Modularity for such graph is: ",get_modularity(G,part))
    print('Writing to file ...')
    # node1 community_of_node1
    # node2 community_of_node2
    pos = nx.spring_layout(G)
    #labels = nx.get_edge_attributes(G,'weight')
    # plt.subplot(222)
    nx.draw_networkx(G, pos, node_size=75, alpha=0.8, node_color=node_cmap)
    if flag=="weighted":
        labels = nx.get_edge_attributes(G, 'weight')
        nx.draw_networkx_edge_labels(G, pos, edge_labels=labels)
    #nx.draw_networkx_edge_labels(G, pos, edge_labels=labels)
    plt.show()
    plotting.plotin3d(G,node_cmap)

    f = open(outfilename, 'w')
    for node in part:
        line = str(node) + " " + str(part[node]) + "\n"
        f.write(line)
    f.close()
    
    #*****BOOKS*****
    
    print('\n\n\n--------Degree Centrality in Book-------- \n')
    for i in range(1,10):
        print("Chapter " + str(i) + ":")
        M = csv_graph(f"hpdata2/book/b{i}.csv")
        x = nx.degree_centrality(M)
        df = pd.DataFrame(list(x.items()), columns=['Node', 'Degree'])
        csv=f'B{i}.csv'
        sub = 'B_Degree'
        os.makedirs(sub, exist_ok=True)
        p = os.path.join(sub, csv)
        df.to_csv(p, index=False)
        midpoint = len(df) // 2
        df1, df2 = df.iloc[:midpoint], df.iloc[midpoint:]
        result_df = pd.concat([df1.reset_index(drop=True), df2.reset_index(drop=True)], axis=1)
        print(result_df)
        print('\n')
    
    print('\n\n\n--------Closeness Centrality in Book-------- \n')
    for i in range(1,10):
        print("Chapter " + str(i) + ":")
        M = csv_graph(f"hpdata2/book/b{i}.csv")
        x = nx.closeness_centrality(M)
        df = pd.DataFrame(list(x.items()), columns=['Node', 'Closeness'])
        csv=f'B{i}.csv'
        sub = 'B_Closeness'
        os.makedirs(sub, exist_ok=True)
        p = os.path.join(sub, csv)
        df.to_csv(p, index=False)
        midpoint = len(df) // 2
        df1, df2 = df.iloc[:midpoint], df.iloc[midpoint:]
        result_df = pd.concat([df1.reset_index(drop=True), df2.reset_index(drop=True)], axis=1)
        print(result_df)
        print('\n')
        
    print('\n\n\n--------Betweenness Centrality in Book-------- \n')
    for i in range(1,10):
        print("Chapter " + str(i) + ":")
        M = csv_graph(f"hpdata2/book/b{i}.csv")
        x = nx.betweenness_centrality(M)
        df = pd.DataFrame(list(x.items()), columns=['Node', 'Betweenness'])
        csv=f'B{i}.csv'
        sub = 'B_Betweenness'
        os.makedirs(sub, exist_ok=True)
        p = os.path.join(sub, csv)
        df.to_csv(p, index=False)
        midpoint = len(df) // 2
        df1, df2 = df.iloc[:midpoint], df.iloc[midpoint:]
        result_df = pd.concat([df1.reset_index(drop=True), df2.reset_index(drop=True)], axis=1)
        print(result_df)
        print('\n')
        
    print('\n\n\n--------Eigenvector Centrality in Book-------- \n')
    for i in range(1,10):
        print("Chapter " + str(i) + ":")
        M = csv_graph(f"hpdata2/book/b{i}.csv")
        x = nx.eigenvector_centrality(M)
        df = pd.DataFrame(list(x.items()), columns=['Node', 'Eigenvector'])
        csv=f'B{i}.csv'
        sub = 'B_EigenVector'
        os.makedirs(sub, exist_ok=True)
        p = os.path.join(sub, csv)
        df.to_csv(p, index=False)
        midpoint = len(df) // 2
        df1, df2 = df.iloc[:midpoint], df.iloc[midpoint:]
        result_df = pd.concat([df1.reset_index(drop=True), df2.reset_index(drop=True)], axis=1)
        print(result_df)
        print('\n')
        
    #*****MOVIES*****   
    
    print('\n\n\n--------Degree Centrality in Movie-------- \n')
    for i in range(1,18):
        print("Scene " + str(i) + ":")
        M = csv_graph(f"hpdata2/movie/m{i}.csv")
        x = nx.degree_centrality(M)
        df = pd.DataFrame(list(x.items()), columns=['Node', 'Degree'])
        csv=f'B{i}.csv'
        sub = 'M_Degree'
        os.makedirs(sub, exist_ok=True)
        p = os.path.join(sub, csv)
        df.to_csv(p, index=False)
        midpoint = len(df) // 2
        df1, df2 = df.iloc[:midpoint], df.iloc[midpoint:]
        result_df = pd.concat([df1.reset_index(drop=True), df2.reset_index(drop=True)], axis=1)
        print(result_df)
        print('\n')
    
    print('\n\n\n--------Closeness Centrality in Movie-------- \n')
    for i in range(1,18):
        print("Scene " + str(i) + ":")
        M = csv_graph(f"hpdata2/movie/m{i}.csv")
        x = nx.closeness_centrality(M)
        df = pd.DataFrame(list(x.items()), columns=['Node', 'Closeness'])
        csv=f'B{i}.csv'
        sub = 'M_Closeness'
        os.makedirs(sub, exist_ok=True)
        p = os.path.join(sub, csv)
        df.to_csv(p, index=False)
        midpoint = len(df) // 2
        df1, df2 = df.iloc[:midpoint], df.iloc[midpoint:]
        result_df = pd.concat([df1.reset_index(drop=True), df2.reset_index(drop=True)], axis=1)
        print(result_df)
        print('\n')
        
    print('\n\n\n--------Betweenness Centrality in Movie-------- \n')
    for i in range(1,18):
        print("Scene " + str(i) + ":")
        M = csv_graph(f"hpdata2/movie/m{i}.csv")
        x = nx.betweenness_centrality(M)
        df = pd.DataFrame(list(x.items()), columns=['Node', 'Betweenness'])
        csv=f'B{i}.csv'
        sub = 'M_Betweenness'
        os.makedirs(sub, exist_ok=True)
        p = os.path.join(sub, csv)
        df.to_csv(p, index=False)
        midpoint = len(df) // 2
        df1, df2 = df.iloc[:midpoint], df.iloc[midpoint:]
        result_df = pd.concat([df1.reset_index(drop=True), df2.reset_index(drop=True)], axis=1)
        print(result_df)
        print('\n')
        
    print('\n\n\n--------Eigenvector Centrality in Movie-------- \n')
    for i in range(1,18):
        print("Scene " + str(i) + ":")
        M = csv_graph(f"hpdata2/movie/m{i}.csv")
        x = nx.eigenvector_centrality(M)
        df = pd.DataFrame(list(x.items()), columns=['Node', 'Eigenvector'])
        csv=f'B{i}.csv'
        sub = 'M_EigenVector'
        os.makedirs(sub, exist_ok=True)
        p = os.path.join(sub, csv)
        df.to_csv(p, index=False)
        midpoint = len(df) // 2
        df1, df2 = df.iloc[:midpoint], df.iloc[midpoint:]
        result_df = pd.concat([df1.reset_index(drop=True), df2.reset_index(drop=True)], axis=1)
        print(result_df)
        print('\n')
main()