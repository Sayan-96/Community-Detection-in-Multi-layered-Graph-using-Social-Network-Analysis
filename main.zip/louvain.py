import pickle
import community
import networkx as nx
import matplotlib.pyplot as plt
from sys import argv
import numpy as np

script, infilename, outfilename = argv


def read_graph(G):
    f = open(infilename, 'r')
    lines = f.readlines()
    global flag

    for line in lines:
        edgelist = list(map(str,line.strip().split(",")))
        u = edgelist[0]
        v = edgelist[1]
        try:
            w = float(edgelist[2])
            G.add_edge(u, v, weight=w)
        except:
            G.add_edge(u, v)
            flag = "unweighted"
    # print u,v,w
    print(G.number_of_nodes(), "nodes")
    print(G.number_of_edges(), "edges")
    save_obj(G, 'Graph_obj_pickle')
    f.close()


def save_obj(obj, filename):
    f = open(filename, 'wb')
    pickle.dump(obj, f)
    f.close()


def main():
    """partitions the graph G into communities"""
    G = nx.Graph()
    read_graph(G)
    print('Computing clusters ...')
    part = community.best_partition(G)
    print(part)
    unique_coms = np.unique(list(part.values()))
    cmap = {
        0: 'maroon',
        1: 'teal',
        2: 'black',
        3: 'orange',
        4: 'green',
        5: 'yellow',
        6: 'red',
        7: 'hotpink',
        8: 'azure',
        9: 'darkolivegreen',
        10: 'turquoise'
    }
    node_cmap = [cmap[v] for _, v in part.items()]
    for comm in set(part.values()):
        print("Community %d" % comm)
        print(', '.join([str(node) for node in part if part[node] == comm]))
    print('Writing to file ...')
    # node1 community_of_node1
    # node2 community_of_node2
    pos = nx.spring_layout(G)
    labels = nx.get_edge_attributes(G,'weight')
    # plt.subplot(222)
    nx.draw_networkx(G, pos, node_size=75, alpha=0.8, node_color=node_cmap)
    nx.draw_networkx_edge_labels(G, pos, edge_labels=labels)
    plt.show()

    f = open(outfilename, 'w')
    for node in part:
        line = str(node) + " " + str(part[node]) + "\n"
        f.write(line)
    f.close()


main()